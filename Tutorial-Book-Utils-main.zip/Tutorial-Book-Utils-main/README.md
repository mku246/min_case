# Tutorial-Book-Utils
various functions used for tutorial book
